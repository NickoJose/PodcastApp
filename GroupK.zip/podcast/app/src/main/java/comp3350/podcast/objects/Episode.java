package comp3350.podcast.objects;
import android.support.annotation.NonNull;
import java.io.Serializable;

public class Episode implements Serializable {

    private String title;
    private String subtitle;
    private String desc;
    private String url;
    private double length;
    private Channel ch; //channel this episode belongs to
    private double timeStamp; //if previously played, episode will resume from this point. This is a percentage.
    private Date publishDate;
    private String author;
    private String category; // AKA genre
    private int epNum; //episode number

    public Episode(String title, String url, String desc,
                   double length, Channel ch,Date publishDate,
                   String author, String category,int epNum)
    {
        this.title = title;
        this.url = url;
        this.desc = desc;
        this.length = length;
        this.ch = ch;
        this.publishDate = publishDate;
        this.author = author;
        this.category = category;
        this.epNum = epNum;
        timeStamp = 0.0;

        publishDate = new Date();
    }

//================================ GETTERS ==========================================//
public String getTitle(){return title;}
public String getUrl(){return url;}
public String getDesc(){return desc;}
public double getLength(){return length;}
public Channel getChannel(){return ch;} //for reference to actual channel
public Date getPublishDate(){return publishDate;}
public String getChannelTitle(){return ch.getTitle();} //for displaying just the name of the channel
public String getAuthor(){return author;}
public String getCategory(){return category;}
public int getEpNum(){return epNum;}
public double getTimeStamp(){return timeStamp;}


//================================ SETTERS ==========================================//
    
    /**
     * Manually set a reference to the channel this episode was posted under
     * 
     * @param ch  - Channel reference being paired to episode
     * @return Returns true on success.
     */
    public boolean setChannel(Channel ch) {
        boolean result = false;
        if (ch != null) {
            this.ch = ch;
            result = true;
        }
        return result;
    }
    
    /**
     * Sets the time stamp as a percentage of completion
     * 
     * @param t - Percent complete that episode is
     * @return void
     */
    public void setTimeStamp(double t) {
        if (t <= length) //just in case
        {
            timeStamp = t;
        } else {
            timeStamp = 0.0;
        }
    }

    /**
     * To String
     * 
     * @return Returns string representing episode. Formatted for convenient GUI use.
     */ 
    public String toString() {
        return ("Episode #"+epNum+"\t\"" + title+"\"");
    }

    /**
     * Checks if a given object represents the same episode. Checks title and source URL.
     * 
     * @param obj  - obj to compare
     * @return Returns true on success.
     */
    public boolean equals(Object obj) {
        boolean result = false;
        Episode ep;

        if (obj instanceof Episode) {
            ep = (Episode) obj;
            if (ep.getTitle().equals(title) && ep.getUrl().equals(url)) {
                result = true;
            }
        }
        return result;
    }

    /**
     * Compare this episode's title/published date/category/length to the target
     *
     * Returns -1 if episode var is less than var
     * Returns 0 if episode var is equal than var
     * Returns 1 if episode var is greater than var
     *
     * @param var  - var to compare
     * @return Returns integer comparison to be used for episode sorting. Episodes are ordered by title, then date posted, then length.
     */
    public int compareTo(@NonNull Object var) {
        int result = 0;

        if (var instanceof String) // compare title
        {
            String otherVar = (String)var;
            if ((result = compareTitle(this.title, otherVar)) != 0)
            {
                return result;
            }
        }

        else if (var instanceof Date)  // compare date published
        {
            Date otherVar = (Date)var;
            if ((result = this.publishDate.compareTo(otherVar)) != 0)
            {
                return result;
            }
        }

        else if (var instanceof Double) // compare length
        {
            double otherVar = (double)var;
            if ((result = compareLength(this.length, otherVar)) != 0)
            {
                return result;
            }
        }

        return result;
    }

    /**
     * Lexiographically compares two titles (as strings)
     * 
     * @param thisTitle  - First title to be compared
     * @param otherTitle - Title being compared to thisTitle
     * @return Returns lexiographic string comparison
     */
    private int compareTitle(String thisTitle, String otherTitle) {
        int result = 0;

        if (thisTitle.compareTo(otherTitle) < 0)
        {
            result = -1;
        }

        else if (thisTitle.compareTo(otherTitle) > 0)
        {
            result = 1;
        }

        return result;
    }

    /**
     * Compares lengths of two episodes as doubles
     * 
     * @param thisLength - first length being compared
     * @param otherLength - second length being compared
     * @return Returns sign of (thisLength - otherLength)
     */    
    private int compareLength(double thisLength, double otherLength) {
        int result = 0;

        if (thisLength < otherLength)
        {
            result = -1;
        }

        else if (thisLength > otherLength)
        {
            result = 1;
        }

        return result;
    }
}
