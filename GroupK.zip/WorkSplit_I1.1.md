| Job            | Time                 | Victim  | Due        | Completed? |
|----------------|----------------------|---------|------------|------------|
| Channel DSO    | 1.5 hr               | Jackson | 2018-01-29 | Yes        |
| Episode DSO    | 1.5 hr               | Jackson | 2018-01-29 | Yes        |
| Sub-List DSO   | 1.5 hr               | Russell | 2018-01-29 | Yes        |
| Playlist DSO   | 1.5 hr               | Russell | 2018-01-29 | Yes        |
| Channel GUI    | 1.5 hr               | Jackson | 2018-02-04 | Yes        |
| Episode GUI    | 1.5 hr               | Jackson | 2018-02-04 | Yes        |
| Sub-List GUI   | 1.5 hr               | Russell | 2018-02-04 |            |
| Playlist GUI   | 1.5 hr               | Russell | 2018-02-04 |            |
| List-View GUI  | (incorporated above) | Russell | 2018-02-04 |            |
| Static Content | 2 hr                 | Nicko   | 2018-01-31 | Yes        |
| Sort Algorithm | 1 hr                 | Nicko   | 2018-02-04 | Yes        |
| Landing Page   | 3 hr                 | Gareth  | 2018-02-04 | Yes        |
| Playscreen     | 6 hr                 | Mike    | 2018-02-04 |            |
